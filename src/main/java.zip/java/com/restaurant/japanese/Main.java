package com.restaurant.japanese;

import com.restaurant.japanese.dao.*;
import com.restaurant.japanese.model.*;
import com.restaurant.japanese.service.AuthService;
import com.restaurant.japanese.service.OrderService;
import com.restaurant.japanese.ui.*;
import com.restaurant.japanese.util.AppState;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main extends Application {

    public static final double WIDTH = 1600;
    public static final double HEIGHT = 900;

    private GraphicsContext gc;
    private AppState currentState = AppState.LOGIN;
    private AppState previousState = AppState.LOGIN;

    private final List<ClickableArea> clickableAreas = new ArrayList<>();
    private ClickableArea hoveredArea = null;

    private User loggedInUser;
    private Order activeOrder;
    private Order lastPaidOrder;
    private List<MenuItem> menuItems;
    private List<Ingredient> lowStockItems = new ArrayList<>();
    private String alertMessage = "";
    private int cartAnimationTime = 0;
    private int alertCheckCounter = 0;

    private String usernameInput = "";
    private String passwordInput = "";
    private boolean isUsernameFocused = true;
    private String loginMessage = "";

    private final AuthService authService = new AuthService();
    private final OrderService orderService = new OrderService();
    private final TableDAO tableDAO = new TableDAO();
    private final OrderDAO orderDAO = new OrderDAO();
    private final MenuItemDAO menuItemDAO = new MenuItemDAO();
    private final InventoryDAO inventoryDAO = new InventoryDAO();
    private final DashboardDAO dashboardDAO = new DashboardDAO();

    private Map<AppState, ScreenRenderer> screenRenderers;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        DatabaseManager.initializeDatabase();

        Pane root = new Pane();
        Canvas canvas = new Canvas(WIDTH, HEIGHT);
        gc = canvas.getGraphicsContext2D();
        root.getChildren().add(canvas);

        loadData();
        initializeRenderers();

        Scene scene = new Scene(root, WIDTH, HEIGHT);
        scene.addEventHandler(KeyEvent.KEY_TYPED, this::handleKeyTyped);
        scene.addEventHandler(KeyEvent.KEY_PRESSED, this::handleKeyPressed);
        canvas.addEventHandler(MouseEvent.MOUSE_CLICKED, this::handleMouseClick);
        canvas.addEventHandler(MouseEvent.MOUSE_MOVED, this::handleMouseMove);
        
        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(16), e -> gameLoop()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

        primaryStage.setTitle("風林火山 Japanese Dining");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }
    
    private void loadData() {
        menuItems = menuItemDAO.getAllMenuItems();
        for(MenuItem item : menuItems) {
            if(item.getImagePath() != null && !item.getImagePath().isEmpty()) {
                try (InputStream is = getClass().getClassLoader().getResourceAsStream(item.getImagePath())) {
                    if (is != null) {
                        item.setImage(new Image(is));
                    }
                } catch (Exception e) {
                    System.err.println("Could not load image: " + item.getImagePath());
                }
            }
        }
    }

    private void initializeRenderers() {
        screenRenderers = new HashMap<>();
        screenRenderers.put(AppState.LOGIN, new LoginScreenRenderer());
        screenRenderers.put(AppState.TABLE_VIEW, new TableViewRenderer());
        screenRenderers.put(AppState.ORDER_TYPE_SELECTION, new OrderTypeScreenRenderer());
        screenRenderers.put(AppState.MENU_SELECTION, new MenuScreenRenderer());
        screenRenderers.put(AppState.ORDER_SUMMARY, new OrderSummaryScreenRenderer());
        screenRenderers.put(AppState.KITCHEN_VIEW, new KitchenScreenRenderer());
        screenRenderers.put(AppState.PAYMENT, new PaymentScreenRenderer());
        screenRenderers.put(AppState.INVENTORY_MANAGEMENT, new InventoryManagementRenderer());
        screenRenderers.put(AppState.DASHBOARD, new DashboardRenderer());
        screenRenderers.put(AppState.FEEDBACK_VIEW, new FeedbackScreenRenderer());
        screenRenderers.put(AppState.SHOWING_ALERT, new AlertRenderer());
    }

    private void gameLoop() {
        update();
        draw();
    }
    
    private void update() {
        if (cartAnimationTime > 0) cartAnimationTime--;

        alertCheckCounter++;
        if (alertCheckCounter > 300) {
            alertCheckCounter = 0;
            if (loggedInUser != null && loggedInUser.getRole() == User.UserRole.MANAGER) {
                lowStockItems = inventoryDAO.getLowStockIngredients();
            }
        }
    }

    private void handleKeyTyped(KeyEvent event) {
        if (currentState == AppState.LOGIN) {
            String character = event.getCharacter();
            if (!character.matches("[\\p{Print}]")) return;
            
            if (isUsernameFocused) {
                usernameInput += character;
            } else {
                passwordInput += character;
            }
        }
    }

    private void handleKeyPressed(KeyEvent event) {
        if (currentState == AppState.LOGIN) {
            if (event.getCode() == KeyCode.BACK_SPACE) {
                if (isUsernameFocused && !usernameInput.isEmpty()) {
                    usernameInput = usernameInput.substring(0, usernameInput.length() - 1);
                } else if (!isUsernameFocused && !passwordInput.isEmpty()) {
                    passwordInput = passwordInput.substring(0, passwordInput.length() - 1);
                }
            } else if (event.getCode() == KeyCode.TAB) {
                isUsernameFocused = !isUsernameFocused;
            } else if (event.getCode() == KeyCode.ENTER) {
                login();
            }
        }
    }
    
    public void login() {
        User user = getAuthService().login(getUsernameInput(), getPasswordInput());
        if (user != null) {
            setLoggedInUser(user);
            changeState(AppState.TABLE_VIEW);
        } else {
            setLoginMessage("Invalid username or password.");
        }
    }

    private void handleMouseClick(MouseEvent event) {
        for (ClickableArea area : new ArrayList<>(clickableAreas)) {
            if (area.contains(event.getX(), event.getY())) {
                area.executeAction();
                break;
            }
        }
    }

    private void handleMouseMove(MouseEvent event) {
        ClickableArea currentlyHovered = null;
        for (ClickableArea area : clickableAreas) {
            if (area.contains(event.getX(), event.getY())) {
                currentlyHovered = area;
                break;
            }
        }
        if (hoveredArea != currentlyHovered) {
            hoveredArea = currentlyHovered;
        }
    }

    private void draw() {
        clickableAreas.clear();
        gc.setFill(StyleConstants.BACKGROUND_COLOR);
        gc.fillRect(0, 0, WIDTH, HEIGHT);

        if (loggedInUser != null) drawHeader();

        AppState stateToRender = (currentState == AppState.SHOWING_ALERT) ? previousState : currentState;
        ScreenRenderer renderer = screenRenderers.get(stateToRender);
        if (renderer != null) {
            renderer.draw(gc, clickableAreas, this);
        }

        if (currentState == AppState.SHOWING_ALERT) {
            screenRenderers.get(AppState.SHOWING_ALERT).draw(gc, clickableAreas, this);
        }
    }

    private void drawHeader() {
        gc.setFill(StyleConstants.PRIMARY_COLOR);
        gc.fillRect(0, 0, WIDTH, 60);
        gc.setFont(StyleConstants.FONT_HEADING_L);
        gc.setFill(StyleConstants.FONT_COLOR_LIGHT);
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText("風林火山 Japanese Dining", WIDTH / 2, 40);
        gc.setTextAlign(TextAlignment.LEFT);

        AbstractScreenRenderer helper = (AbstractScreenRenderer) screenRenderers.get(AppState.LOGIN);
        
        helper.drawButton(gc, clickableAreas, this, "Tables", 20, 15, 100, 30, () -> changeState(AppState.TABLE_VIEW));
        helper.drawButton(gc, clickableAreas, this, "Takeaway", 140, 15, 120, 30, () -> changeState(AppState.ORDER_TYPE_SELECTION));
        helper.drawButton(gc, clickableAreas, this, "Kitchen", 280, 15, 100, 30, () -> changeState(AppState.KITCHEN_VIEW));
        
        if (loggedInUser.getRole() == User.UserRole.MANAGER) {
            helper.drawButton(gc, clickableAreas, this, "Dashboard", 400, 15, 120, 30, () -> changeState(AppState.DASHBOARD));
            helper.drawButton(gc, clickableAreas, this, "Inventory", 540, 15, 120, 30, () -> changeState(AppState.INVENTORY_MANAGEMENT));
        }
        
        // --- Right Side Elements ---
        double rightX = WIDTH - 20;
        
        drawCart(rightX - 60, 15);
        rightX -= 70;

        drawAlertIcon(rightX - 40, 15);
        rightX -= 50;
        
        helper.drawButton(gc, clickableAreas, this, "Logout", rightX - 80, 15, 80, 30, this::logout);
        rightX -= 100;
        
        gc.setFill(StyleConstants.FONT_COLOR_LIGHT);
        gc.setFont(StyleConstants.FONT_BODY_S);
        gc.setTextAlign(TextAlignment.RIGHT);
        gc.fillText("User: " + loggedInUser.getUsername() + " (" + loggedInUser.getRole() + ")", rightX, 35);
        gc.setTextAlign(TextAlignment.LEFT);
    }
    
    // FIXED: Restored full drawing logic for the cart icon
    private void drawCart(double x, double y) {
        double cartWidth = 60;
        double cartHeight = 40;
        clickableAreas.add(new ClickableArea(x - 10, y - 10, cartWidth, cartHeight, () -> {
            if (activeOrder != null) {
                changeState(AppState.ORDER_SUMMARY);
            } else {
                setAlertMessage("No active order. Please select a table or start a takeaway order first.");
                changeState(AppState.SHOWING_ALERT);
            }
        }));

        int itemCount = (activeOrder != null) ? activeOrder.getTotalItemCount() : 0;
        double scale = (cartAnimationTime > 0) ? 1.0 + Math.sin(Math.PI * (30 - cartAnimationTime) / 30.0) * 0.2 : 1.0;
        double cx = x + 15;
        double cy = y + 20;

        gc.save();
        gc.translate(cx, cy);
        gc.scale(scale, scale);
        gc.translate(-cx, -cy);

        gc.setStroke(StyleConstants.FONT_COLOR_LIGHT);
        gc.setLineWidth(2);
        
        if (hoveredArea != null && hoveredArea.contains(x, y)) {
            gc.setStroke(Color.YELLOW);
        }

        gc.strokePolygon(new double[]{x, x + 5, x + 35, x + 30}, new double[]{y, y + 20, y + 20, y}, 4);
        gc.strokeLine(x + 30, y, x + 35, y - 5);
        gc.strokeOval(x + 8, y + 21, 6, 6);
        gc.strokeOval(x + 25, y + 21, 6, 6);

        gc.restore();

        if (itemCount > 0) {
            double badgeX = x + 28;
            double badgeY = y - 8;
            double badgeSize = 20;

            gc.setFill(cartAnimationTime > 0 ? Color.YELLOW : StyleConstants.PRIMARY_COLOR.brighter());
            gc.fillOval(badgeX, badgeY, badgeSize, badgeSize);
            gc.setStroke(StyleConstants.FONT_COLOR_LIGHT);
            gc.strokeOval(badgeX, badgeY, badgeSize, badgeSize);

            gc.setFill(cartAnimationTime > 0 ? Color.BLACK : StyleConstants.FONT_COLOR_LIGHT);
            gc.setFont(StyleConstants.FONT_BUTTON);
            gc.setTextAlign(TextAlignment.CENTER);
            gc.fillText(String.valueOf(itemCount), badgeX + badgeSize / 2, badgeY + badgeSize / 2 + 5);
            gc.setTextAlign(TextAlignment.LEFT);
        }
    }

    // FIXED: Restored full drawing logic for the alert icon
    private void drawAlertIcon(double x, double y) {
        if (loggedInUser == null || loggedInUser.getRole() != User.UserRole.MANAGER) return;

        double bellWidth = 30;
        double bellHeight = 30;

        Color bellColor = StyleConstants.FONT_COLOR_LIGHT;
        if (hoveredArea != null && hoveredArea.contains(x, y)) {
            bellColor = Color.YELLOW;
        }
        
        gc.save();
        gc.setStroke(bellColor);
        gc.setFill(bellColor);
        gc.setLineWidth(2);

        // Main bell shape using an arc
        gc.strokeArc(x + 5, y + 5, 20, 20, 20, 140, ArcType.OPEN);
        // Flared bottom rim
        gc.strokeLine(x + 2, y + 17, x + 28, y + 17);
        // Clapper (small circle inside)
        gc.fillOval(x + 12, y + 18, 6, 6);

        gc.restore();
        
        if (!lowStockItems.isEmpty()) {
            gc.setFill(Color.YELLOW);
            gc.fillOval(x + 20, y, 12, 12);
            
            clickableAreas.add(new ClickableArea(x, y, bellWidth, bellHeight, () -> {
                StringBuilder sb = new StringBuilder("The following ingredients are low on stock:");
                lowStockItems.forEach(item -> sb.append(String.format("\n- %s (Stock: %d, Min: %d)", item.getName(), item.getQuantity(), item.getMinStockLevel())));
                setAlertMessage(sb.toString());
                changeState(AppState.SHOWING_ALERT);
            }));
        }
    }

    public void triggerCartAnimation() { this.cartAnimationTime = 30; }

    public void changeState(AppState newState) {
        this.previousState = this.currentState;
        this.currentState = newState;
        loginMessage = "";
    }
    public void changeState(AppState newState, AppState previous) {
        this.previousState = previous;
        this.currentState = newState;
    }
    
    public void logout() {
        loggedInUser = null;
        activeOrder = null;
        lastPaidOrder = null;
        usernameInput = "";
        passwordInput = "";
        isUsernameFocused = true;
        changeState(AppState.LOGIN);
    }
    
    // Getters for DAOs and Services
    public AuthService getAuthService() { return authService; }
    public OrderService getOrderService() { return orderService; }
    public TableDAO getTableDAO() { return tableDAO; }
    public OrderDAO getOrderDAO() { return orderDAO; }
    public MenuItemDAO getMenuItemDAO() { return menuItemDAO; }
    public InventoryDAO getInventoryDAO() { return inventoryDAO; }
    public DashboardDAO getDashboardDAO() { return dashboardDAO; }
    public User getLoggedInUser() { return loggedInUser; }
    public void setLoggedInUser(User user) { this.loggedInUser = user; }
    public Order getActiveOrder() { return activeOrder; }
    public void setActiveOrder(Order order) { this.activeOrder = order; }
    public Order getLastPaidOrder() { return lastPaidOrder; }
    public void setLastPaidOrder(Order order) { this.lastPaidOrder = order; }
    public List<MenuItem> getMenuItems() { return menuItems; }
    public ClickableArea getHoveredArea() { return hoveredArea; }
    public String getAlertMessage() { return alertMessage; }
    public void setAlertMessage(String message) { this.alertMessage = message; }
    public AppState getPreviousState() { return previousState; }
    public String getUsernameInput() { return usernameInput; }
    public String getPasswordInput() { return passwordInput; }
    public boolean isUsernameFocused() { return isUsernameFocused; }
    public void focusUsername() { this.isUsernameFocused = true; }
    public void focusPassword() { this.isUsernameFocused = false; }
    public String getLoginMessage() { return loginMessage; }
    public void setLoginMessage(String msg) { this.loginMessage = msg; }
}