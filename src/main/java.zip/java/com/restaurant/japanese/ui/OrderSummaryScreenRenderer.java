package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.exception.InsufficientStockException;
import com.restaurant.japanese.model.ClickableArea;
import com.restaurant.japanese.model.Order;
import com.restaurant.japanese.model.OrderItem;
import com.restaurant.japanese.util.AppState;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;

import java.util.List;

public class OrderSummaryScreenRenderer extends AbstractScreenRenderer {
    @Override
    public void draw(GraphicsContext gc, List<ClickableArea> clickableAreas, Main app) {
        Order activeOrder = app.getActiveOrder();
        if (activeOrder == null) {
            gc.setFont(StyleConstants.FONT_BODY_M);
            gc.setFill(Color.GRAY);
            gc.fillText("No active order. Please select a table or start a takeaway order.", 50, 150);
            return;
        }
        
        activeOrder = app.getOrderDAO().getOrderById(activeOrder.getId());
        app.setActiveOrder(activeOrder);

        final Order finalActiveOrder = activeOrder;

        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setFont(StyleConstants.FONT_HEADING_M);
        gc.fillText("Order Summary", 50, 100);

        double yPos = 140;
        if (finalActiveOrder.getItems().isEmpty()) {
            gc.setFont(StyleConstants.FONT_BODY_M);
            gc.setFill(Color.GRAY);
            gc.fillText("This order is empty. Please add items from the menu.", 50, yPos + 10);
        } else {
            gc.setStroke(Color.GRAY);
            gc.strokeLine(50, yPos - 20, Main.WIDTH - 50, yPos - 25);

            for (OrderItem item : new java.util.ArrayList<>(finalActiveOrder.getItems())) {
                gc.setFont(StyleConstants.FONT_BODY_M);
                gc.setFill(Color.DARKSLATEBLUE);
                gc.fillText(item.getMenuItem().getName(), 60, yPos + 10);

                gc.setFill(StyleConstants.FONT_COLOR_DARK);
                String priceText = String.format("₹%.2f", item.getPrice());
                gc.fillText(priceText, 450, yPos + 10);

                drawQuantityControls(gc, clickableAreas, app, item, 650, yPos - 10);
                
                drawCheckbox(gc, clickableAreas, app, 950, yPos - 10, "Sugar-Free (+₹15.00)", item.isCustomSugarFree(), () -> {
                    app.getOrderDAO().toggleSugarFree(
                        finalActiveOrder.getId(),
                        item.getMenuItem().getId(),
                        item.getQuantity(),
                        item.isCustomSugarFree()
                    );
                });
                yPos += 40;
            }
            gc.strokeLine(50, yPos, Main.WIDTH - 50, yPos);
            yPos += 30;
        }

        gc.setFont(StyleConstants.FONT_BODY_M);
        gc.setFill(Color.DARKRED);
        gc.fillText("Prefs: " + finalActiveOrder.getPreferences().toString(), 50, yPos);
        yPos += 40;

        gc.setFont(StyleConstants.FONT_HEADING_M);
        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.fillText(String.format("Total: ₹%.2f", finalActiveOrder.getTotalPrice()), 50, yPos);
        yPos += 60;

        if (finalActiveOrder.getStatus() == Order.OrderStatus.PENDING) {
            drawButton(gc, clickableAreas, app, "Confirm & Send to Kitchen", 50, yPos, 300, 50, () -> {
                if (!finalActiveOrder.getItems().isEmpty()) {
                    try {
                        // FIXED: This call can now throw an exception, which we catch
                        app.getOrderService().confirmOrder(finalActiveOrder);
                        
                        if (finalActiveOrder.getTableId() != null) {
                            app.getTableDAO().updateTableStatus(finalActiveOrder.getTableId(), com.restaurant.japanese.model.Table.TableStatus.OCCUPIED);
                        }
                        app.setAlertMessage("Order sent to the kitchen successfully!");
                        app.changeState(AppState.SHOWING_ALERT, AppState.TABLE_VIEW);
                        app.setActiveOrder(null);
                    } catch (InsufficientStockException e) {
                        app.setAlertMessage("Order Failed: " + e.getMessage());
                        app.changeState(AppState.SHOWING_ALERT);
                    }
                } else {
                    app.setAlertMessage("Cannot confirm an empty order.");
                    app.changeState(AppState.SHOWING_ALERT);
                }
            });
        }
        
        if (finalActiveOrder.getTableId() != null && (finalActiveOrder.getStatus() != Order.OrderStatus.PENDING && finalActiveOrder.getStatus() != Order.OrderStatus.PAID)) {
            drawButton(gc, clickableAreas, app, "Proceed to Payment", 370, yPos, 220, 50, () -> {
                app.changeState(AppState.PAYMENT);
            });
        }
    }

    private void drawQuantityControls(GraphicsContext gc, List<ClickableArea> areas, Main app, OrderItem item, double x, double y) {
        drawButton(gc, areas, app, "-", x, y, 25, 25, () -> {
            app.getOrderDAO().updateOrderItem(app.getActiveOrder().getId(), item.getMenuItem().getId(), item.isCustomSugarFree(), item.getQuantity() - 1);
        });
        
        gc.setFont(StyleConstants.FONT_BODY_M);
        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText(String.valueOf(item.getQuantity()), x + 50, y + 18);
        gc.setTextAlign(TextAlignment.LEFT);

        drawButton(gc, areas, app, "+", x + 75, y, 25, 25, () -> {
            if (app.getOrderService().canFulfillItem(item.getMenuItem())) {
                app.getOrderDAO().updateOrderItem(app.getActiveOrder().getId(), item.getMenuItem().getId(), item.isCustomSugarFree(), item.getQuantity() + 1);
            } else {
                app.setAlertMessage("Not enough ingredients for more " + item.getMenuItem().getName());
                app.changeState(AppState.SHOWING_ALERT, AppState.ORDER_SUMMARY);
            }
        });
        
        drawButton(gc, areas, app, "X", x + 130, y, 25, 25, () -> {
             app.getOrderDAO().removeOrderItem(app.getActiveOrder().getId(), item.getMenuItem().getId(), item.isCustomSugarFree());
        });
    }
}