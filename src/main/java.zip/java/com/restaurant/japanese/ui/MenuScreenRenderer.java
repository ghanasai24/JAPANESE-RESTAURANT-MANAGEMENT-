package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import com.restaurant.japanese.model.MenuItem;
import com.restaurant.japanese.model.Order;
import com.restaurant.japanese.util.AppState;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;

import java.util.List;

public class MenuScreenRenderer extends AbstractScreenRenderer {

    @Override
    public void draw(GraphicsContext gc, List<ClickableArea> clickableAreas, Main app) {
        if (app.getActiveOrder() == null) {
            gc.setFont(StyleConstants.FONT_HEADING_M);
            gc.setFill(Color.DARKRED);
            gc.setTextAlign(TextAlignment.CENTER);
            gc.fillText("Please select a Table or start a Takeaway order first.", Main.WIDTH / 2, Main.HEIGHT / 2);
            gc.setTextAlign(TextAlignment.LEFT);
            return;
        }

        double yPos = 80;
        for (MenuItem item : app.getMenuItems()) {
            boolean isAvailable = app.getOrderService().canFulfillItem(item);

            gc.setFill(Color.WHITE);
            gc.fillRoundRect(50, yPos, Main.WIDTH - 100, 120, 15, 15);
            gc.setStroke(StyleConstants.PRIMARY_COLOR);
            gc.strokeRoundRect(50, yPos, Main.WIDTH - 100, 120, 15, 15);

            double imageX = 65;
            double imageY = yPos + 10;
            double imageSize = 100;
            Image dishImage = item.getImage();
            if (dishImage != null && !dishImage.isError()) {
                gc.drawImage(dishImage, imageX, imageY, imageSize, imageSize);
            } else {
                gc.setFill(Color.LIGHTGRAY);
                gc.fillRect(imageX, imageY, imageSize, imageSize);
                gc.setFill(Color.DARKGRAY);
                gc.setTextAlign(TextAlignment.CENTER);
                gc.setFont(StyleConstants.FONT_BODY_S);
                gc.fillText("No Image", imageX + imageSize / 2, imageY + imageSize / 2);
                gc.setTextAlign(TextAlignment.LEFT);
            }

            double textX = imageX + imageSize + 20;

            gc.setFill(StyleConstants.FONT_COLOR_DARK);
            gc.setFont(StyleConstants.FONT_HEADING_S);
            gc.fillText(item.getName(), textX, yPos + 30);

            gc.setFont(StyleConstants.FONT_BODY_S);
            gc.setFill(Color.DARKGRAY);
            drawWrappedText(gc, item.getDescription(), textX, yPos + 50, 600, TextAlignment.LEFT);

            drawStars(gc, item.getAverageRating(), textX, yPos + 95, 15, Color.ORANGE);
            gc.setFont(StyleConstants.FONT_BODY_S);
            gc.setFill(Color.GRAY);
            gc.fillText("(" + item.getNumberOfRatings() + ")", textX + 5 * (15 * 1.2) + 5, yPos + 100);

            gc.setFont(StyleConstants.FONT_HEADING_S);
            gc.setFill(StyleConstants.ACCENT_COLOR_GREEN);
            gc.setTextAlign(TextAlignment.RIGHT);
            gc.fillText(String.format("₹%.2f", item.getBasePrice()), Main.WIDTH - 220, yPos + 40);
            gc.setTextAlign(TextAlignment.LEFT);

            if (isAvailable) {
                drawButton(gc, clickableAreas, app, "Add to Cart", Main.WIDTH - 200, yPos + 70, 130, 40, () -> {
                    Order currentOrder = app.getActiveOrder();
                    if (currentOrder == null) {
                        app.setAlertMessage("Please select a table or start a takeaway order before adding items.");
                        app.changeState(AppState.SHOWING_ALERT, AppState.TABLE_VIEW);
                        return;
                    }
                    
                    // 1. Update the database
                    app.getOrderDAO().addOrUpdateItemInOrder(currentOrder.getId(), item.getId(), false);
                    
                    // 2. Re-fetch the order from the DB to get the updated state
                    Order updatedOrder = app.getOrderDAO().getOrderById(currentOrder.getId());
                    app.setActiveOrder(updatedOrder);
                    
                    // 3. Trigger visual feedback
                    app.triggerCartAnimation();
                });
            } else {
                gc.setFill(StyleConstants.DISABLED_COLOR);
                gc.fillRoundRect(Main.WIDTH - 200, yPos + 70, 130, 40, 10, 10);
                gc.setFill(Color.WHITE);
                gc.setFont(StyleConstants.FONT_BUTTON);
                gc.setTextAlign(TextAlignment.CENTER);
                gc.fillText("Out of Stock", Main.WIDTH - 135, yPos + 95);
                gc.setTextAlign(TextAlignment.LEFT);
            }
            yPos += 140;
        }

        // --- Jain Preference Checkbox ---
        Order activeOrder = app.getActiveOrder();
        if (activeOrder != null) {
            gc.setFill(StyleConstants.FONT_COLOR_DARK);
            gc.setFont(StyleConstants.FONT_HEADING_S);
            gc.fillText("Special Dietary Requirements:", 50, yPos);
            boolean isJain = activeOrder.getPreferences().isJain();
            drawCheckbox(gc, clickableAreas, app, 50, yPos + 20, "Jain (No Onion/Garlic)", isJain, () -> {
                Order order = app.getActiveOrder();
                order.getPreferences().setJain(!isJain);
                app.getOrderDAO().updateOrder(order);
            });
        }
    }
}