package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import com.restaurant.japanese.model.Order;
import com.restaurant.japanese.model.Table;
import com.restaurant.japanese.model.User;
import com.restaurant.japanese.util.AppState;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TableViewRenderer extends AbstractScreenRenderer {
    @Override
    public void draw(GraphicsContext gc, List<ClickableArea> clickableAreas, Main app) {
        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setFont(StyleConstants.FONT_HEADING_M);
        gc.fillText("Table Layout", 50, 100);

        List<Table> tables = app.getTableDAO().getAllTables();
        
        List<Order> readyOrders = app.getOrderDAO().getOrdersByStatus(Order.OrderStatus.READY);
        Map<Integer, Order> tableIdToReadyOrderMap = readyOrders.stream()
            .filter(o -> o.getTableId() != null)
            .collect(Collectors.toMap(Order::getTableId, o -> o));

        int cols = 8;
        double hSpacing = 180;
        double vSpacing = 180;
        double size = 140;
        double startX = 100;
        double startY = 150;

        for (int i = 0; i < tables.size(); i++) {
            Table table = tables.get(i);
            int row = i / cols;
            int col = i % cols;
            double x = startX + col * hSpacing;
            double y = startY + row * vSpacing;

            Color fillColor;
            boolean isFoodReady = tableIdToReadyOrderMap.containsKey(table.getId());

            if (isFoodReady) {
                fillColor = StyleConstants.TABLE_FOOD_READY;
            } else {
                fillColor = switch (table.getStatus()) {
                    case OCCUPIED -> StyleConstants.TABLE_OCCUPIED;
                    case NEEDS_CLEANING -> StyleConstants.TABLE_NEEDS_CLEANING;
                    default -> StyleConstants.TABLE_AVAILABLE;
                };
            }
            
            gc.setFill(fillColor);
            gc.fillRoundRect(x, y, size, size, 20, 20);
            
            if (app.getHoveredArea() != null && app.getHoveredArea().contains(x,y)) {
                gc.setStroke(Color.YELLOW);
                gc.setLineWidth(4);
                gc.strokeRoundRect(x, y, size, size, 20, 20);
                gc.setLineWidth(1);
            }

            gc.setFill(StyleConstants.FONT_COLOR_LIGHT);
            gc.setFont(StyleConstants.FONT_HEADING_M);
            gc.setTextAlign(TextAlignment.CENTER);
            gc.fillText(String.valueOf(table.getTableNumber()), x + size / 2, y + size / 2 + 10);
            
            gc.setFont(StyleConstants.FONT_BODY_S);
            String statusText = isFoodReady ? "FOOD READY" : table.getStatus().name().replace("_", " ");
            gc.fillText(statusText, x + size / 2, y + size - 20);
            gc.setTextAlign(TextAlignment.LEFT);
            
            clickableAreas.add(new ClickableArea(x, y, size, size, () -> handleTableClick(app, table, isFoodReady)));
        }
    }
    
    private void handleTableClick(Main app, Table table, boolean isFoodReady) {
        if (isFoodReady) {
            Order readyOrder = app.getOrderDAO().getPendingOrderByTable(table.getId());
            if (readyOrder != null) {
                readyOrder.setStatus(Order.OrderStatus.SERVED);
                app.getOrderDAO().updateOrder(readyOrder);
                app.setAlertMessage("Order for Table " + table.getTableNumber() + " marked as SERVED.");
                app.changeState(AppState.SHOWING_ALERT);
            }
            return;
        }

        switch (table.getStatus()) {
            case AVAILABLE:
                Order newOrder = app.getOrderDAO().createOrder(Order.OrderType.DINE_IN, table.getId(), null);
                // FIXED: Add a null check to ensure the order was created
                if (newOrder != null) {
                    app.setActiveOrder(newOrder);
                    app.changeState(AppState.MENU_SELECTION);
                } else {
                    app.setAlertMessage("Error: Could not create a new order in the database.");
                    app.changeState(AppState.SHOWING_ALERT);
                }
                break;
            case OCCUPIED:
                Order existingOrder = app.getOrderDAO().getPendingOrderByTable(table.getId());
                if (existingOrder != null) {
                    app.setActiveOrder(existingOrder);
                    app.changeState(AppState.ORDER_SUMMARY);
                } else {
                     app.setAlertMessage("Could not find an active order for this table. It may need cleaning.");
                     app.changeState(AppState.SHOWING_ALERT);
                }
                break;
            case NEEDS_CLEANING:
                if (app.getLoggedInUser().getRole() == User.UserRole.MANAGER) {
                    app.getTableDAO().updateTableStatus(table.getId(), Table.TableStatus.AVAILABLE);
                    app.setAlertMessage("Table " + table.getTableNumber() + " is now clean and available.");
                    app.changeState(AppState.SHOWING_ALERT);
                } else {
                    app.setAlertMessage("This table needs to be cleaned by a manager.");
                    app.changeState(AppState.SHOWING_ALERT);
                }
                break;
        }
    }
}