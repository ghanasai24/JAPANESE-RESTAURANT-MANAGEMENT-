package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import java.util.List;

public abstract class AbstractScreenRenderer implements ScreenRenderer {

    public void drawButton(GraphicsContext gc, List<ClickableArea> areas, Main app, String text, double x, double y, double w, double h, Runnable action) {
        ClickableArea area = new ClickableArea(x, y, w, h, action);
        areas.add(area);

        if (area == app.getHoveredArea()) {
            gc.setFill(StyleConstants.PRIMARY_HOVER_COLOR);
        } else {
            gc.setFill(StyleConstants.PRIMARY_COLOR);
        }
        gc.fillRoundRect(x, y, w, h, 10, 10);

        gc.setFill(StyleConstants.FONT_COLOR_LIGHT);
        gc.setFont(StyleConstants.FONT_BUTTON);
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText(text, x + w / 2, y + h / 2 + 5);
        gc.setTextAlign(TextAlignment.LEFT);
    }

    public void drawCheckbox(GraphicsContext gc, List<ClickableArea> areas, Main app, double x, double y, String label, boolean isChecked, Runnable action) {
        double boxSize = 20;
        Text textNode = new Text(label);
        textNode.setFont(StyleConstants.FONT_BODY_S);
        double labelWidth = textNode.getLayoutBounds().getWidth();
        ClickableArea area = new ClickableArea(x, y, 20 + 10 + labelWidth, boxSize, action);
        areas.add(area);

        gc.setStroke(StyleConstants.FONT_COLOR_DARK);
        gc.strokeRect(x, y, boxSize, boxSize);

        if (isChecked) {
            gc.setFill(area == app.getHoveredArea() ? StyleConstants.PRIMARY_HOVER_COLOR : StyleConstants.PRIMARY_COLOR);
            gc.fillRect(x + 4, y + 4, boxSize - 8, boxSize - 8);
        } else if (area == app.getHoveredArea()){
            gc.setFill(StyleConstants.BACKGROUND_COLOR.brighter());
            gc.fillRect(x + 1, y + 1, boxSize - 2, boxSize - 2);
        }

        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setFont(StyleConstants.FONT_BODY_S);
        gc.fillText(label, x + boxSize + 10, y + boxSize - 4);
    }

    public double drawWrappedText(GraphicsContext gc, String text, double x, double y, double maxWidth, TextAlignment alignment) {
        if (text == null) return y;
        gc.setTextAlign(alignment);
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        double currentY = y;
        double lineHeight = gc.getFont().getSize() * 1.4;

        for (String word : words) {
            Text textNode = new Text(line + word);
            textNode.setFont(gc.getFont());
            if (textNode.getLayoutBounds().getWidth() > maxWidth) {
                gc.fillText(line.toString().trim(), x, currentY);
                currentY += lineHeight;
                line = new StringBuilder(word + " ");
            } else {
                line.append(word).append(" ");
            }
        }
        gc.fillText(line.toString().trim(), x, currentY);
        gc.setTextAlign(TextAlignment.LEFT);
        return currentY + lineHeight;
    }
    
    public void drawTextInput(GraphicsContext gc, String text, String label, double x, double y, double w, double h, boolean isFocused) {
        gc.setFill(Color.WHITE);
        gc.fillRoundRect(x, y, w, h, 10, 10);
        
        if (isFocused) {
            gc.setStroke(StyleConstants.PRIMARY_COLOR);
            gc.setLineWidth(2);
        } else {
            gc.setStroke(Color.GRAY);
            gc.setLineWidth(1);
        }
        gc.strokeRoundRect(x, y, w, h, 10, 10);
        gc.setLineWidth(1);

        gc.setFont(StyleConstants.FONT_BODY_M);
        gc.setFill(StyleConstants.FONT_COLOR_DARK);

        String displayText = text;
        if (label.toLowerCase().contains("password")) {
            displayText = "*".repeat(text.length());
        }

        gc.fillText(displayText, x + 10, y + h / 2 + 5);

        if(isFocused && System.currentTimeMillis() % 1000 < 500) {
            Text textNode = new Text(displayText);
            textNode.setFont(gc.getFont());
            double textWidth = textNode.getLayoutBounds().getWidth();
            gc.setStroke(StyleConstants.FONT_COLOR_DARK);
            gc.strokeLine(x + 10 + textWidth + 2, y + 8, x + 10 + textWidth + 2, y + h - 8);
        }
        
        gc.setFont(StyleConstants.FONT_BODY_S);
        gc.setFill(Color.GRAY);
        gc.fillText(label, x + 5, y - 8);
    }

    // FIXED: Changed from 'private' to 'protected' to allow subclasses to use it
    protected void drawSingleStar(GraphicsContext gc, double centerX, double centerY, double size, boolean isFilled) {
        double[] xPoints = new double[10];
        double[] yPoints = new double[10];

        for (int j = 0; j < 10; j++) {
            double radius = (j % 2 == 0) ? size / 2 : size / 4;
            double angle = Math.PI * j / 5 - Math.PI / 2;
            xPoints[j] = centerX + radius * Math.cos(angle);
            yPoints[j] = centerY + radius * Math.sin(angle);
        }

        if (isFilled) {
            gc.fillPolygon(xPoints, yPoints, 10);
        } else {
            gc.strokePolygon(xPoints, yPoints, 10);
        }
    }

    public void drawStars(GraphicsContext gc, double rating, double x, double y, double size, Color color) {
        gc.save();
        gc.setStroke(color);
        gc.setFill(color);
        gc.setLineWidth(1.5);
        gc.setLineCap(StrokeLineCap.ROUND);

        for (int i = 0; i < 5; i++) {
            double currentX = x + i * (size * 1.2);
            drawSingleStar(gc, currentX, y, size, (i < rating));
        }
        gc.restore();
    }
}