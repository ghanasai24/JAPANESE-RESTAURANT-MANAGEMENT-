package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import com.restaurant.japanese.model.Ingredient;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;
import java.util.List;

public class InventoryManagementRenderer extends AbstractScreenRenderer {
    @Override
    public void draw(GraphicsContext gc, List<ClickableArea> clickableAreas, Main app) {
        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setFont(StyleConstants.FONT_HEADING_M);
        gc.fillText("Inventory Management", 50, 100);

        List<Ingredient> ingredients = app.getInventoryDAO().getAllIngredients();
        
        double yPos = 150;
        gc.setFont(StyleConstants.FONT_BODY_M);
        gc.setStroke(Color.GRAY);
        
        // Header
        gc.fillText("Ingredient Name", 50, yPos);
        gc.fillText("Current Stock", 400, yPos);
        gc.fillText("Min. Stock", 600, yPos);
        gc.fillText("Actions", 800, yPos);
        gc.strokeLine(50, yPos + 10, Main.WIDTH - 50, yPos + 10);
        yPos += 40;

        for (Ingredient ingredient : ingredients) {
            boolean isLow = ingredient.getQuantity() <= ingredient.getMinStockLevel();
            gc.setFill(isLow ? Color.RED : StyleConstants.FONT_COLOR_DARK);
            
            gc.fillText(ingredient.getName(), 50, yPos);
            gc.setTextAlign(TextAlignment.CENTER);
            gc.fillText(String.valueOf(ingredient.getQuantity()), 450, yPos);
            gc.fillText(String.valueOf(ingredient.getMinStockLevel()), 650, yPos);
            gc.setTextAlign(TextAlignment.LEFT);

            // Restock buttons
            drawButton(gc, clickableAreas, app, "+10", 800, yPos - 18, 50, 25, () -> {
                app.getInventoryDAO().updateIngredientQuantity(ingredient.getId(), ingredient.getQuantity() + 10);
            });
            drawButton(gc, clickableAreas, app, "+50", 860, yPos - 18, 50, 25, () -> {
                app.getInventoryDAO().updateIngredientQuantity(ingredient.getId(), ingredient.getQuantity() + 50);
            });
            
            yPos += 40;
        }
    }
}