package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.text.TextAlignment;
import java.util.List;

public class AlertRenderer extends AbstractScreenRenderer {
    @Override
    public void draw(GraphicsContext gc, List<ClickableArea> clickableAreas, Main app) {
        gc.setFill(StyleConstants.DIALOG_OVERLAY);
        gc.fillRect(0, 0, Main.WIDTH, Main.HEIGHT);

        double boxW = 500;
        double boxH = 200;
        double boxX = (Main.WIDTH - boxW) / 2;
        double boxY = (Main.HEIGHT - boxH) / 2;

        gc.setFill(StyleConstants.BACKGROUND_COLOR.brighter());
        gc.fillRoundRect(boxX, boxY, boxW, boxH, 15, 15);
        gc.setStroke(StyleConstants.FONT_COLOR_DARK);
        gc.strokeRoundRect(boxX, boxY, boxW, boxH, 15, 15);

        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setFont(StyleConstants.FONT_HEADING_S);
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText("Notification", boxX + boxW / 2, boxY + 40);

        gc.setFont(StyleConstants.FONT_BODY_M);
        drawWrappedText(gc, app.getAlertMessage(), boxX + boxW / 2, boxY + 80, boxW - 40, TextAlignment.CENTER);

        drawButton(gc, clickableAreas, app, "OK", boxX + (boxW - 100) / 2, boxY + 140, 100, 40, () -> {
            app.changeState(app.getPreviousState());
        });
    }
}