package com.restaurant.japanese.ui;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public final class StyleConstants {
    // Colors
    public static final Color PRIMARY_COLOR = Color.web("#8B0000"); // Dark Red
    public static final Color PRIMARY_HOVER_COLOR = Color.web("#A52A2A"); // Lighter Red
    public static final Color BACKGROUND_COLOR = Color.web("#F5F5DC"); // Beige
    public static final Color FONT_COLOR_LIGHT = Color.WHITE;
    public static final Color FONT_COLOR_DARK = Color.BLACK;
    public static final Color ACCENT_COLOR_GREEN = Color.web("#4CAF50");
    public static final Color DIALOG_OVERLAY = new Color(0, 0, 0, 0.6);
    public static final Color DISABLED_COLOR = Color.gray(0.5, 0.7);

    // Table Status Colors
    public static final Color TABLE_AVAILABLE = Color.web("#2E8B57"); // SeaGreen
    public static final Color TABLE_OCCUPIED = Color.web("#B22222"); // FireBrick
    public static final Color TABLE_NEEDS_CLEANING = Color.web("#FF8C00"); // DarkOrange
    public static final Color TABLE_FOOD_READY = Color.web("#32CD32"); // LimeGreen
    
    // Fonts (FIXED: Switched to SansSerif for better Unicode support)
    public static final Font FONT_HEADING_L = Font.font("SansSerif", FontWeight.BOLD, 28);
    public static final Font FONT_HEADING_M = Font.font("SansSerif", FontWeight.BOLD, 24);
    public static final Font FONT_HEADING_S = Font.font("SansSerif", FontWeight.BOLD, 20);
    public static final Font FONT_BUTTON = Font.font("SansSerif", FontWeight.BOLD, 14);
    public static final Font FONT_BODY_M = Font.font("SansSerif", FontWeight.NORMAL, 16);
    public static final Font FONT_BODY_S = Font.font("SansSerif", FontWeight.NORMAL, 14);
}