package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import com.restaurant.japanese.model.Order;
import com.restaurant.japanese.model.Table;
import com.restaurant.japanese.util.AppState;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;
import java.util.List;

public class PaymentScreenRenderer extends AbstractScreenRenderer {
    
    // CORRECT PLACEMENT: This must be an instance variable, outside of any methods.
    private int splitBy = 1;

    @Override
    public void draw(GraphicsContext gc, List<ClickableArea> clickableAreas, Main app) {
        Order order = app.getActiveOrder();
        if (order == null) {
            app.changeState(AppState.TABLE_VIEW);
            return;
        }

        // --- Bill Section ---
        double billX = 50;
        double billY = 100;
        double billW = 500;
        
        gc.setFill(Color.WHITE);
        gc.fillRoundRect(billX, billY, billW, 600, 15, 15);
        gc.setStroke(StyleConstants.FONT_COLOR_DARK);
        gc.strokeRoundRect(billX, billY, billW, 600, 15, 15);
        
        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setFont(StyleConstants.FONT_HEADING_S);
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText("Final Bill", billX + billW/2, billY + 40);
        
        gc.setFont(StyleConstants.FONT_BODY_M);
        gc.setTextAlign(TextAlignment.LEFT);
        
        double lineY = billY + 80;
        // This loop draws each item on the bill
        for (var item : order.getItems()) {
             lineY = drawWrappedText(gc, item.toString(), billX + 20, lineY, 300, TextAlignment.LEFT);
             gc.setTextAlign(TextAlignment.RIGHT);
             gc.fillText(String.format("₹%.2f", item.getPrice()), billX + billW - 20, lineY - (gc.getFont().getSize() * 1.4));
             gc.setTextAlign(TextAlignment.LEFT);
        }

        lineY = billY + 400;
        gc.setStroke(Color.GRAY);
        gc.strokeLine(billX + 20, lineY, billX + billW - 20, lineY);
        lineY += 30;
        
        gc.fillText("Subtotal:", billX + 20, lineY);
        gc.setTextAlign(TextAlignment.RIGHT);
        gc.fillText(String.format("₹%.2f", order.getTotalPrice()), billX + billW - 20, lineY);
        gc.setTextAlign(TextAlignment.LEFT);
        lineY += 30;
        
        gc.fillText("GST (5%):", billX + 20, lineY);
        gc.setTextAlign(TextAlignment.RIGHT);
        gc.fillText(String.format("₹%.2f", order.getGst()), billX + billW - 20, lineY);
        gc.setTextAlign(TextAlignment.LEFT);
        lineY += 40;

        gc.setFont(StyleConstants.FONT_HEADING_S);
        gc.fillText("Grand Total:", billX + 20, lineY);
        gc.setTextAlign(TextAlignment.RIGHT);
        gc.fillText(String.format("₹%.2f", order.getFinalPrice()), billX + billW - 20, lineY);
        gc.setTextAlign(TextAlignment.LEFT);
        
        // --- Payment & Split Bill Section ---
        double paymentX = billX + billW + 100;
        double paymentY = billY;
        gc.setFont(StyleConstants.FONT_HEADING_S);
        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.fillText("Split Bill", paymentX, paymentY + 40);
        
        drawButton(gc, clickableAreas, app, "-", paymentX, paymentY + 70, 40, 40, () -> {
            if (splitBy > 1) splitBy--;
        });
        gc.setFont(StyleConstants.FONT_HEADING_L);
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText(String.valueOf(splitBy), paymentX + 100, paymentY + 100);
        gc.setTextAlign(TextAlignment.LEFT);
        drawButton(gc, clickableAreas, app, "+", paymentX + 160, paymentY + 70, 40, 40, () -> splitBy++);

        if (splitBy > 1) {
            gc.setFont(StyleConstants.FONT_HEADING_S);
            gc.setFill(StyleConstants.ACCENT_COLOR_GREEN);
            gc.fillText(String.format("₹%.2f / person", order.getFinalPrice() / splitBy), paymentX, paymentY + 160);
        }

        gc.setFont(StyleConstants.FONT_HEADING_S);
        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.fillText("Select Payment Method", paymentX, paymentY + 250);
        
        drawButton(gc, clickableAreas, app, "Pay with Cash", paymentX, paymentY + 280, 200, 50, () -> processPayment(app, order, Order.PaymentMethod.CASH));
        drawButton(gc, clickableAreas, app, "Pay with Card", paymentX, paymentY + 340, 200, 50, () -> processPayment(app, order, Order.PaymentMethod.CARD));
        drawButton(gc, clickableAreas, app, "Pay with UPI", paymentX, paymentY + 400, 200, 50, () -> processPayment(app, order, Order.PaymentMethod.UPI));
    }
    
    private void processPayment(Main app, Order order, Order.PaymentMethod method) {
        order.setStatus(Order.OrderStatus.PAID);
        order.setPaymentMethod(splitBy > 1 ? Order.PaymentMethod.MULTIPLE : method);
        app.getOrderDAO().updateOrder(order);

        if (order.getTableId() != null) {
            app.getTableDAO().updateTableStatus(order.getTableId(), Table.TableStatus.NEEDS_CLEANING);
        }

        app.setLastPaidOrder(order);
        app.setActiveOrder(null);
        splitBy = 1; // Reset split for next time
        app.changeState(AppState.FEEDBACK_VIEW);
    }
}