package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import com.restaurant.japanese.model.Order;
import com.restaurant.japanese.model.OrderItem;
import com.restaurant.japanese.model.Table;
import com.restaurant.japanese.util.AppState;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;

import java.util.ArrayList;
import java.util.List;

public class KitchenScreenRenderer extends AbstractScreenRenderer {
    @Override
    public void draw(GraphicsContext gc, List<ClickableArea> clickableAreas, Main app) {
        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setFont(StyleConstants.FONT_HEADING_M);
        gc.fillText("Kitchen Display - Active Orders", 50, 100);

        List<Order> confirmedOrders = app.getOrderDAO().getOrdersByStatus(Order.OrderStatus.CONFIRMED);
        List<Order> preparingOrders = app.getOrderDAO().getOrdersByStatus(Order.OrderStatus.PREPARING);
        List<Order> allActiveOrders = new ArrayList<>();
        allActiveOrders.addAll(confirmedOrders);
        allActiveOrders.addAll(preparingOrders);

        if (allActiveOrders.isEmpty()) {
            gc.setFont(StyleConstants.FONT_BODY_M);
            gc.setFill(Color.GRAY);
            gc.fillText("No active orders in the kitchen.", 50, 150);
            return;
        }

        double xPos = 50;
        double yPos = 130;
        int ordersInRow = 4;
        double cardWidth = 350;
        double cardHeight = 400;
        double hGap = 40;
        double vGap = 40;

        for (int i = 0; i < allActiveOrders.size(); i++) {
            Order order = allActiveOrders.get(i);
            int row = i / ordersInRow;
            int col = i % ordersInRow;

            double currentX = xPos + col * (cardWidth + hGap);
            double currentY = yPos + row * (cardHeight + vGap);

            gc.setFill(order.getStatus() == Order.OrderStatus.PREPARING ? Color.web("#fff8e1") : Color.web("#FFFFE0"));
            gc.fillRoundRect(currentX, currentY, cardWidth, cardHeight, 15, 15);
            gc.setStroke(Color.web("#8B4513"));
            gc.strokeRoundRect(currentX, currentY, cardWidth, cardHeight, 15, 15);

            double innerY = currentY + 30;
            gc.setFill(StyleConstants.FONT_COLOR_DARK);
            gc.setFont(StyleConstants.FONT_HEADING_S);
            String title = order.getOrderType() == Order.OrderType.DINE_IN
                    ? "Table " + app.getTableDAO().getTableById(order.getTableId()).getTableNumber()
                    : order.getOrderType().name();
            gc.fillText(title, currentX + 20, innerY);

            gc.setFont(StyleConstants.FONT_BUTTON);
            gc.setFill(order.getStatus() == Order.OrderStatus.PREPARING ? Color.ORANGE.darker() : Color.BLUE);
            gc.setTextAlign(TextAlignment.RIGHT);
            gc.fillText(order.getStatus().name(), currentX + cardWidth - 20, innerY);
            gc.setTextAlign(TextAlignment.LEFT);
            innerY += 25;

            gc.setStroke(Color.GRAY);
            gc.strokeLine(currentX + 10, innerY, currentX + cardWidth - 10, innerY);
            innerY += 25;

            gc.setFill(StyleConstants.FONT_COLOR_DARK);
            gc.setFont(StyleConstants.FONT_BODY_S);
            for (OrderItem item : order.getItems()) {
                innerY = drawWrappedText(gc, "- " + item, currentX + 20, innerY, cardWidth - 40, TextAlignment.LEFT);
            }

            gc.setFill(Color.DARKRED);
            gc.setFont(StyleConstants.FONT_BUTTON);
            drawWrappedText(gc, "Prefs: " + order.getPreferences().toString(), currentX + 20, currentY + cardHeight - 80, cardWidth - 40, TextAlignment.LEFT);

            double buttonY = currentY + cardHeight - 55;
            double buttonW = 180;
            double buttonX = currentX + (cardWidth - buttonW) / 2;

            if (order.getStatus() == Order.OrderStatus.CONFIRMED) {
                drawButton(gc, clickableAreas, app, "Start Preparing", buttonX, buttonY, buttonW, 40, () -> {
                    order.setStatus(Order.OrderStatus.PREPARING);
                    app.getOrderDAO().updateOrder(order);
                });
            } else if (order.getStatus() == Order.OrderStatus.PREPARING) {
                drawButton(gc, clickableAreas, app, "Mark as Ready", buttonX, buttonY, buttonW, 40, () -> {
                    order.setStatus(Order.OrderStatus.READY);
                    app.getOrderDAO().updateOrder(order);
                });
            }
        }
    }
}