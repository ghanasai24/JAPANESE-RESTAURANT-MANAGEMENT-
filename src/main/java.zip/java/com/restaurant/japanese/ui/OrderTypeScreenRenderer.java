package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import com.restaurant.japanese.model.Order;
import com.restaurant.japanese.util.AppState;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.text.TextAlignment;

import java.util.List;

public class OrderTypeScreenRenderer extends AbstractScreenRenderer {
    @Override
    public void draw(GraphicsContext gc, List<ClickableArea> clickableAreas, Main app) {
        double centerX = Main.WIDTH / 2;
        
        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setFont(StyleConstants.FONT_HEADING_M);
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText("Select Order Type", centerX, 150);

        // Takeaway Button
        drawButton(gc, clickableAreas, app, "Takeaway", centerX - 150, 250, 300, 80, () -> {
            Order order = app.getOrderDAO().createOrder(Order.OrderType.TAKEAWAY, null, "000-0000"); // Placeholder phone
            // FIXED: Add a null check
            if (order != null) {
                app.setActiveOrder(order);
                app.changeState(AppState.MENU_SELECTION);
            } else {
                app.setAlertMessage("Error: Could not create a new takeaway order.");
                app.changeState(AppState.SHOWING_ALERT);
            }
        });

        // Delivery Button
        drawButton(gc, clickableAreas, app, "Delivery", centerX - 150, 350, 300, 80, () -> {
            Order order = app.getOrderDAO().createOrder(Order.OrderType.DELIVERY, null, "111-1111"); // Placeholder phone
            // FIXED: Add a null check
            if (order != null) {
                app.setActiveOrder(order);
                app.changeState(AppState.MENU_SELECTION);
            } else {
                app.setAlertMessage("Error: Could not create a new delivery order.");
                app.changeState(AppState.SHOWING_ALERT);
            }
        });
        
        gc.setTextAlign(TextAlignment.LEFT); // Reset alignment
    }
}