package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;
import java.util.Map;

public class DashboardRenderer extends AbstractScreenRenderer {
    @Override
    public void draw(GraphicsContext gc, java.util.List<ClickableArea> clickableAreas, Main app) {
        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setFont(StyleConstants.FONT_HEADING_M);
        gc.fillText("Manager Dashboard", 50, 100);

        // --- Today's Sales ---
        double sales = app.getDashboardDAO().getTodaysSales();
        gc.setFont(StyleConstants.FONT_HEADING_S);
        gc.fillText("Today's Total Sales:", 50, 150);
        gc.setFont(StyleConstants.FONT_HEADING_L);
        gc.setFill(StyleConstants.ACCENT_COLOR_GREEN);
        gc.fillText(String.format("₹%.2f", sales), 300, 150);

        // --- Top Selling Items ---
        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setFont(StyleConstants.FONT_HEADING_S);
        gc.fillText("Top 5 Selling Items (Today)", 50, 220);
        
        Map<String, Integer> popularItems = app.getDashboardDAO().getPopularItemsToday();
        
        if (popularItems.isEmpty()) {
            gc.setFont(StyleConstants.FONT_BODY_M);
            gc.setFill(Color.GRAY);
            gc.fillText("No sales data for today yet.", 50, 260);
            return;
        }

        double barX = 50;
        double barY = 260;
        double maxBarWidth = Main.WIDTH - 250;
        double barHeight = 40;
        
        int maxQuantity = popularItems.values().stream().mapToInt(v -> v).max().orElse(1);

        gc.setFont(StyleConstants.FONT_BODY_M);
        for (Map.Entry<String, Integer> entry : popularItems.entrySet()) {
            double barWidth = (double) entry.getValue() / maxQuantity * maxBarWidth;
            
            // Draw bar
            gc.setFill(StyleConstants.PRIMARY_COLOR);
            gc.fillRect(barX, barY, barWidth, barHeight);

            // Draw text on bar
            gc.setFill(StyleConstants.FONT_COLOR_LIGHT);
            gc.fillText(entry.getKey(), barX + 10, barY + barHeight / 2 + 5);

            // Draw quantity next to bar
            gc.setFill(StyleConstants.FONT_COLOR_DARK);
            gc.fillText(entry.getValue().toString(), barX + barWidth + 10, barY + barHeight / 2 + 5);
            
            barY += barHeight + 15;
        }
    }
}