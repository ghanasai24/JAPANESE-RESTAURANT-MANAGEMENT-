package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import com.restaurant.japanese.model.Order;
import com.restaurant.japanese.model.OrderItem;
import com.restaurant.japanese.util.AppState;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FeedbackScreenRenderer extends AbstractScreenRenderer {
    // This map stores the rating for each menu item ID
    private Map<Integer, Integer> ratings = new HashMap<>();

    @Override
    public void draw(GraphicsContext gc, List<ClickableArea> clickableAreas, Main app) {
        Order lastOrder = app.getLastPaidOrder();
        if (lastOrder == null) {
            app.changeState(AppState.TABLE_VIEW);
            return;
        }

        // Initialize ratings map on the first draw for this order
        if (ratings.isEmpty()) { 
            for(OrderItem item : lastOrder.getItems()) {
                ratings.put(item.getMenuItem().getId(), 0);
            }
        }

        gc.setFill(StyleConstants.FONT_COLOR_DARK);
        gc.setFont(StyleConstants.FONT_HEADING_M);
        gc.fillText("How was your meal?", 50, 100);

        double yPos = 150;
        gc.setFont(StyleConstants.FONT_BODY_M);
        for (OrderItem item : lastOrder.getItems()) {
            gc.fillText(item.getMenuItem().getName(), 50, yPos + 15);
            
            int currentRating = ratings.getOrDefault(item.getMenuItem().getId(), 0);

            // FIXED: Loop to draw 5 individual, clickable stars
            for (int i = 1; i <= 5; i++) {
                double starCenterX = 400 + (i - 1) * 40;
                double starCenterY = yPos + 15;
                double starSize = 30;
                
                final int ratingValue = i;
                clickableAreas.add(new ClickableArea(starCenterX - starSize/2, starCenterY - starSize/2, starSize, starSize, () -> {
                    ratings.put(item.getMenuItem().getId(), ratingValue);
                }));
                
                // Use the new helper to draw one star at a time
                gc.save();
                gc.setStroke(Color.ORANGE);
                gc.setFill(Color.ORANGE);
                gc.setLineWidth(1.5);
                // Call the new single star helper, filling it if its index is less than or equal to the current rating
                drawSingleStar(gc, starCenterX, starCenterY, starSize, (i <= currentRating));
                gc.restore();
            }
            yPos += 50;
        }
        
        drawButton(gc, clickableAreas, app, "Submit Feedback", 50, yPos + 50, 200, 50, () -> {
            ratings.forEach((menuItemId, rating) -> {
                if (rating > 0) {
                    app.getMenuItemDAO().addRating(menuItemId, rating, ""); // Empty comment for now
                }
            });
            ratings.clear();
            app.setLastPaidOrder(null);
            app.changeState(AppState.TABLE_VIEW);
        });
        
        drawButton(gc, clickableAreas, app, "Skip", 270, yPos + 50, 100, 50, () -> {
            ratings.clear();
            app.setLastPaidOrder(null);
            app.changeState(AppState.TABLE_VIEW);
        });
    }
}