package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import com.restaurant.japanese.model.User;
import com.restaurant.japanese.util.AppState;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;
import java.util.List;

public class LoginScreenRenderer extends AbstractScreenRenderer {
    @Override
    public void draw(GraphicsContext gc, List<ClickableArea> clickableAreas, Main app) {
        double centerX = Main.WIDTH / 2;
        
        // --- Title ---
        gc.setFill(StyleConstants.PRIMARY_COLOR);
        gc.setFont(StyleConstants.FONT_HEADING_L);
        gc.setTextAlign(TextAlignment.CENTER);
        gc.fillText("Restaurant Management System", centerX, 150);

        // FIXED: Reset text alignment immediately after using CENTER alignment
        gc.setTextAlign(TextAlignment.LEFT);

        // --- Input Fields ---
        double fieldWidth = 400;
        double fieldHeight = 50;
        
        drawTextInput(gc, app.getUsernameInput(), "Username", centerX - fieldWidth / 2, 250, fieldWidth, fieldHeight, app.isUsernameFocused());
        drawTextInput(gc, app.getPasswordInput(), "Password", centerX - fieldWidth / 2, 350, fieldWidth, fieldHeight, !app.isUsernameFocused());
        
        clickableAreas.add(new ClickableArea(centerX - fieldWidth / 2, 250, fieldWidth, fieldHeight, app::focusUsername));
        clickableAreas.add(new ClickableArea(centerX - fieldWidth / 2, 350, fieldWidth, fieldHeight, app::focusPassword));

        // --- Login Button ---
        drawButton(gc, clickableAreas, app, "Login", centerX - 100, 450, 200, 50, app::login);

        // --- Error Message ---
        if (app.getLoginMessage() != null && !app.getLoginMessage().isEmpty()) {
            gc.setFill(Color.RED);
            gc.setFont(StyleConstants.FONT_BODY_M);
            gc.setTextAlign(TextAlignment.CENTER);
            gc.fillText(app.getLoginMessage(), centerX, 530);
            gc.setTextAlign(TextAlignment.LEFT); // Reset again just in case
        }
    }
}