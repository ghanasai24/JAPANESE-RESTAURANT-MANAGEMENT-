package com.restaurant.japanese.ui;

import com.restaurant.japanese.Main;
import com.restaurant.japanese.model.ClickableArea;
import javafx.scene.canvas.GraphicsContext;
import java.util.List;

public interface ScreenRenderer {
    void draw(GraphicsContext gc, List<ClickableArea> clickableAreas, Main app);
}